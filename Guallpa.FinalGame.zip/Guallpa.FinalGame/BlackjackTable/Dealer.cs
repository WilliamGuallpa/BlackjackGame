﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJackGame
{
    public class Dealer : Player
    {

        public Dealer() 
        { 
          
        }

        private bool rules()
        {
            int cardCount = _numOpenCards + 1;
            String[] theCards = new String[cardCount];
            theCards[0] = _closedCard;
            for (int n = 1; n < _openCards.Length + 1; n++)
                theCards[n] = _openCards[n - 1];
            
            Score theNumericValue = new Score();
            theNumericValue.calcDealerScoreWithAce(theCards);
            int value = theNumericValue.getHandValue();


            if (value < 17)
                return false;
            else
                return true;
            //if value < 17 hit = true 
            //else stay = false


        }
    }
}
