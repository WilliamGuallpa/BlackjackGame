﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJackGame
{
    public class Score
    {
       

        public Score() { }

        public int calcHandValueWithAce(String[] theCards)
        {
            setHandValue(theCards);
            return handValue;
        }

        public int calcHandValueWithoutAce(String[] theCards)
        {
            handValue = 0;
            theCards = removeSuit(theCards);
            calcScoreWithoutAce(theCards);
            return handValue;
        }

      

        private int calcPlayerScoreWithAce(String[] theCards, String closedCard)
        {
            theCards = CompletePlayerHand(theCards, closedCard);

            int handValue = 0;
            theCards = removeSuit(theCards);

            handValue = calcScoreWithoutAce(theCards);

            for (int n = 0; n < theCards.Length; n++)
            {
                if (theCards[n] == null)
                    continue;
                theCards[n] = theCards[n].ToLower();
                if (theCards[n].Equals("ace"))
                {
                    if (handValue + 11 < 22)
                        handValue += 11;
                    else
                        handValue++;
                }
            }
            return handValue;
        }

        private String[] CompletePlayerHand(string[] theCards, string closedCard)
        {
            String[] temp = new String[theCards.Length + 1];
            temp[0] = closedCard;
            for (int n = 0; n < temp.Length; n++)
                temp[n] = theCards[n - 1];
            theCards = temp;
            return theCards;
        }

        public int calcDealerScoreWithAce(String[] theCards, String _closedCard)
        {
            theCards = CompletePlayerHand(theCards, _closedCard);

            int handValue = 0;
            theCards = removeSuit(theCards);
            handValue =  calcScoreWithoutAce(theCards);

            for (int n = 0; n < theCards.Length; n++)
            {
               if( )
                theCards[n] = theCards[n].ToLower();
                if (theCards[n].Equals("ace"))
                    handValue += 11;
            }
            return handValue;
        }

        private int calcScoreWithoutAce(String[] theCards)
        {
            int handValue = 0;
            for (int n = 0; n < theCards.Length; n++)
            {
                if (theCards[n] != null)
                {
                    if (theCards[n].Length < 3)//number card
                        handValue += Convert.ToInt16(theCards[n]);
                    else if (theCards[n].Length > 3)//picture card - not ace
                        handValue += 10;
                }
            }
            return handValue;
        }

        private String[] removeSuit(String[] theCards)
        {
            for (int n = 0; n < theCards.Length; n++)
            {
                if (theCards[n] == null)
                    continue;

                theCards[n] = theCards[n].Substring(0, theCards[n].IndexOf(" "));//get rid of the suit
                theCards[n] = theCards[n].Trim();//get rid of extra trailing blnaks
            }

            return theCards;
        }
    }
}



