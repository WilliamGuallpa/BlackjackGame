﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJackGame
{
    public class Deck
    {
        private String[] theDeck = null;
        private int numberOfCardsInTheDeck = -1;

        public Deck() 
        { 
            
        }

        public Deck(String s)
        {
            numberOfCardsInTheDeck = Convert.ToInt32(s);
        }

        public bool setNumberOfCardsInTheDeck(String s)
        {
            if(s!=null&&s.Length>0)
            {
                numberOfCardsInTheDeck = Convert.ToInt32(s);
                return true;
            }

            return false;
        }

        public String[] getTheDeck()
        { 
            return theDeck; 
        }
    }
}
