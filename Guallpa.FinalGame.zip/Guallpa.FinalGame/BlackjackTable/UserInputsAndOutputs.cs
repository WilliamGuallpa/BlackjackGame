﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentFromTheBeginning
{
    public class UserInputsAndOutputs
    {
        public UserInputsAndOutputs() { }

        public void displayMessageToUser(String message) 
        { 
            Console.WriteLine(message);
        }

        public String getDataFromUser(String message)
        {
            Console.Write(message);
            return Console.ReadLine();
        }
    }
}
