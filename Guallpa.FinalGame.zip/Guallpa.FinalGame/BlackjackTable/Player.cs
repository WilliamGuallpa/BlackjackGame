﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJackGame
{
    public class Player
    {
        protected String _closedCard = null;
        protected String[] _openCards = new String[10];
        protected int _numOpenCards = 0;
        public Player()
        {
            
        }

        public bool addOneCardToOpenCards(String newCard)
        {
           if(_numOpenCards >= _openCards.Length) 
             return false;
            
            _openCards[_numOpenCards] = newCard;
            _numOpenCards++;

            return true;
        }

        public String[] getOpenCards()
        {
            return _openCards;
        }

        public bool setClosedCard(String s) 
        { 
            if (s!=null&&s.Length>0)
                return false;
            
                _closedCard = s;
                return true;
        }

        public String getClosedCard() 
        {
            return _closedCard;

        }
    }
}
