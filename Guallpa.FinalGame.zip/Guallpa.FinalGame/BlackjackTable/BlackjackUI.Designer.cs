﻿namespace BlackjackTable
{
    partial class frmBlackjackUI
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnDeal = new Button();
            btnHit = new Button();
            btnStay = new Button();
            btnExit = new Button();
            lblDealersCards = new Label();
            lblPlayersCards = new Label();
            lblDealerScore = new Label();
            lblPlayerScore = new Label();
            SuspendLayout();
            // 
            // btnDeal
            // 
            btnDeal.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            btnDeal.Location = new Point(32, 145);
            btnDeal.Name = "btnDeal";
            btnDeal.Size = new Size(252, 120);
            btnDeal.TabIndex = 0;
            btnDeal.Text = "Deal";
            btnDeal.UseVisualStyleBackColor = true;
            // 
            // btnHit
            // 
            btnHit.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            btnHit.Location = new Point(32, 307);
            btnHit.Name = "btnHit";
            btnHit.Size = new Size(252, 120);
            btnHit.TabIndex = 1;
            btnHit.Text = "Hit";
            btnHit.UseVisualStyleBackColor = true;
            // 
            // btnStay
            // 
            btnStay.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            btnStay.Location = new Point(32, 469);
            btnStay.Name = "btnStay";
            btnStay.Size = new Size(252, 120);
            btnStay.TabIndex = 2;
            btnStay.Text = "Stay";
            btnStay.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            btnExit.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            btnExit.Location = new Point(32, 627);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(252, 120);
            btnExit.TabIndex = 3;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            // 
            // lblDealersCards
            // 
            lblDealersCards.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            lblDealersCards.Location = new Point(673, 56);
            lblDealersCards.Name = "lblDealersCards";
            lblDealersCards.Size = new Size(432, 83);
            lblDealersCards.TabIndex = 4;
            lblDealersCards.Text = "Dealer's Cards:";
            // 
            // lblPlayersCards
            // 
            lblPlayersCards.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            lblPlayersCards.Location = new Point(662, 582);
            lblPlayersCards.Name = "lblPlayersCards";
            lblPlayersCards.Size = new Size(432, 83);
            lblPlayersCards.TabIndex = 5;
            lblPlayersCards.Text = "Player's Cards:";
            // 
            // lblDealerScore
            // 
            lblDealerScore.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            lblDealerScore.Location = new Point(1298, 64);
            lblDealerScore.Name = "lblDealerScore";
            lblDealerScore.Size = new Size(241, 75);
            lblDealerScore.TabIndex = 6;
            lblDealerScore.Text = "Score:";
            // 
            // lblPlayerScore
            // 
            lblPlayerScore.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            lblPlayerScore.Location = new Point(1298, 590);
            lblPlayerScore.Name = "lblPlayerScore";
            lblPlayerScore.Size = new Size(241, 75);
            lblPlayerScore.TabIndex = 7;
            lblPlayerScore.Text = "Score:";
            // 
            // frmBlackjackUI
            // 
            AutoScaleDimensions = new SizeF(15F, 37F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(0, 192, 0);
            ClientSize = new Size(1757, 961);
            Controls.Add(lblPlayerScore);
            Controls.Add(lblDealerScore);
            Controls.Add(lblPlayersCards);
            Controls.Add(lblDealersCards);
            Controls.Add(btnExit);
            Controls.Add(btnStay);
            Controls.Add(btnHit);
            Controls.Add(btnDeal);
            Name = "frmBlackjackUI";
            Text = "BlackjackUI";
            ResumeLayout(false);
        }

        #endregion

        private Button btnDeal;
        private Button btnHit;
        private Button btnStay;
        private Button btnExit;
        private Label lblDealersCards;
        private Label lblPlayersCards;
        private Label lblDealerScore;
        private Label lblPlayerScore;
    }
}