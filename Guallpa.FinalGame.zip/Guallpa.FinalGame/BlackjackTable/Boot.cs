﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJackGame
{
    public class Boot
    {
        private String[] theCards = null;
        private int cardToDeal = -1;
        private int numberOfDecks = 4;
        public Boot()
        {
            initializeTheCards();
        }

        private void initializeTheCards()
        {
            Deck aDeck = new Deck();
            String[] cards = aDeck.getTheDeck();

            theCards = new String[cards.Length * numberOfDecks];

            for (int n = 0, p = 0; n < theCards.Length; n++, p++) 
            { 
                if (p == cards.Length)
                    p = 0;

                theCards[n] = cards[p];
            }
            Shuffle sfl = new Shuffle(theCards);
            theCards = sfl.getTheShuffledDeck();
            cardToDeal = theCards.Length - 1;

        }
        private void reshuffleTheBoot()
        {
            Shuffle mixThem = new Shuffle(theCards);

            theCards = mixThem.getTheShuffledDeck();

            cardToDeal = theCards.Length;
        }

       
        public String dealOneCard()
        {
            cardToDeal--;

            if (cardToDeal < 53)
            {
                reshuffleTheBoot();
                cardToDeal--;
            }

            return theCards[cardToDeal];
        }
    }
}
