﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJackGame
{
    public class Shuffle
    {
        private String[] theShuffledDeck = null;
        private String[] theUnshuffledDeck = null;

        public Shuffle() { }

        public Shuffle(String[] aDeck)
        {
            theShuffledDeck = aDeck;
        }

        public bool setUnshuffledDeck(String[] s)
        {
            if (s != null && s.Length > 0)
            {
                theUnshuffledDeck = s;
                return true;
            }
            return false;

        }

        public String[] getTheShuffledDeck()
        {
            return theShuffledDeck;
        }

    }
}
