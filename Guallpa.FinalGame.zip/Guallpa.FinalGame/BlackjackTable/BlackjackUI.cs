using BlackJackGame;

namespace BlackjackTable
{
    public partial class frmBlackjackUI : Form
    {
        //Attribute
        private Boot _boot = new Boot();
        private StudentFromTheBeginning.UserInputsAndOutputs _inOut = new StudentFromTheBeginning.UserInputsAndOutputs();
        private Dealer _dealer = new Dealer();
        private Player _player = new Player();

        public frmBlackJackTable()
        {
            InitializeComponent();
        }

        private void frmBlackJackTable_Load(object sender, EventArgs e)
        {
            lblPlayersScore.Text = "";
            newGameDeal();


        }

        private void newGameDeal()
        {
            _player.setClosedCard(obtainOneCard());
            _dealer.setClosedCard(obtainOneCard());
            _player.addOneCardToOpenCards(obtainOneCard());
            _dealer.addOneCardToOpenCards(obtainOneCard());

            displayPlayersHand();
            displayDealerHand();


            // hitOrStayPlayer();
        }

        private String obtainOneCard()
        {
            return _boot.dealOneCard();
        }


        public void displayPlayersHand()
        {
            String[] open = _player.getOpenCards();
            String closed = _player.getClosedCard();

            lblPlayersCards.Visible = true;

            lblPlayersCards.Text = "[" + closed + "]\n\n";

            for (int n = 0; n < open.Length; n++)
                lblPlayersCards.Text += open[n] + "\n";


        }


        public void displayDealerHand()
        {

            String[] open = _dealer.getOpenCards();
            //String closed = _dealer.getClosedCard();

            lblDealersCards.Visible = true;

            lblDealersCards.Text = "[closed]" + "\n\n";

            for (int n = 0; n < open.Length; n++)
                lblDealersCards.Text += open[n] + "\n";
        }

        public void displayPlayerScore()
        {
            Score scr = new Score();

            lblPlayerScore.Visible = true;

            lblPlayerScore.Text = (scr.calcPlayerScoreWithAce(_player.getOpenCards(), _player.getClosedCard())).ToString();
        }

        public void displayDealerScore()
        {
            Score scr = new Score();

            lblDealerScore.Visible = true;

            lblDealerScore.Text = (scr.calcDealerScoreWithAce(_dealer.getOpenCards(), _dealer.getClosedCard())).ToString();

        }



        public void hitOrStayPlayer()
        {
            Score scr = new Score();
            int playerScore = 0;

            if (_player.getOpenCards()[9] != null)
            {
                displayPlayerScore();
                hitOrStayDealer();
            }

            displayPlayersHand();

            playerScore = scr.calcPlayerScoreWithAce(_player.getOpenCards(), _player.getClosedCard());
            if (playerScore == 21)
            {
                int dealerScore = scr.calcDealerScoreWithAce(_dealer.getOpenCards(), _dealer.getClosedCard());
                decideWinner(playerScore, dealerScore);
                return;
            }


            if (playerScore > 21)
            {
                decideWinner(playerScore, 0);
                return;
            }

            _player.addOneCardToOpenCards(obtainOneCard());

            btnHit.Enabled = true;
            btnStay.Enabled = true;
        }



        public void hitOrStayDealer()
        {
            Score scr = new Score();
            int dealerScore = 0;
            int playerScore = 0;

            displayDealerHand();

            dealerScore = scr.calcDealerScoreWithAce(_dealer.getOpenCards(), _dealer.getClosedCard());
            if (dealerScore == 21)
            {
                playerScore = scr.calcDealerScoreWithAce(_dealer.getOpenCards(), _dealer.getClosedCard());
                decideWinner(playerScore, dealerScore);
                return;
            }

            if (dealerScore > 21)
            {
                decideWinner(dealerScore, 0);
                return;
            }

            if (_dealer.enforcingDealerRule())
            {
                _dealer.addOneCardToOpenCards(obtainOneCard());
                hitOrStayDealer();
            }
            else //Dealer stays
            {
                decideWinner(playerScore, dealerScore); // dealer Stays
            }

            hitOrStayDealer();
        }


        public void decideWinner(int playerScore, int dealerScore)
        {
            lblWinOrLose.Visible = true;


            if (playerScore > 21)
            {
                //show player hand 
                //dealer wins
                return;
            }

            if (dealerScore > 21)
            {
                //show both hand 
                //player wins
                return;
            }

            if (dealerScore == 21 && playerScore == 21)
            {
                //Show both hands
                //push game
                return;
            }

            if (playerScore == 21)
            {
                // Show player hand
                // player wins
                return;
            }


            if (dealerScore == 21)
            {
                // Show both hands
                // dealer wins
                return;
            }

            if (playerScore == dealerScore)
            {
                //Show both hands
                //push game
                return;
            }


        }

        public void playAgain()
        {

        }

        private void btnHit_Click(object sender, EventArgs e)
        {

            hitOrStayPlayer();

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnStay_Click(object sender, EventArgs e)
        {
            displayPlayerScore();
            hitOrStayDealer();
        }
    }
}
}